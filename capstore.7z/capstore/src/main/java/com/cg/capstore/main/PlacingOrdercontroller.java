package com.cg.capstore.main;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.cg.capstore.bean.Orders;
import com.cg.capstore.bean.Product;
import com.cg.capstore.service.IOrderService;

public class PlacingOrdercontroller {
	
	@Autowired
	private IOrderService OrderService;
	
	@PostMapping("/checkAvailabilityInInventory")//
	public ResponseEntity<Boolean> checkAvailabilityInInventory(@RequestBody Product product) {
		if (OrderService.checkAvailabilityInInventory(product)) {
			return new ResponseEntity<Boolean>(true, HttpStatus.OK);
		} else {
			return new ResponseEntity<Boolean>(false, HttpStatus.NOT_FOUND);
		}
	}
	

	@PostMapping("/placeOrder")
	public ResponseEntity<Product> placeOrder(@RequestBody Product product) {
		Product nullproduct = null;
		if (!OrderService.checkAvailabilityInInventory(product)) {
			return new ResponseEntity<Product>(nullproduct, HttpStatus.OK);
		}
		
		Product newproduct = OrderService.placeOrder(product);
		if (newproduct!=null) {
			return new ResponseEntity<Product>(newproduct, HttpStatus.OK);
		} else {
			return new ResponseEntity<Product>(nullproduct, HttpStatus.NOT_FOUND);
		}
	}

	@PostMapping("/deliverOrderAndUpdateInventory")//
	public ResponseEntity<Boolean> deliverOrderAndUpdateInventory(@RequestBody Orders order,@RequestBody Product product) {
		if (OrderService.deliverOrderAndUpdateInventory(order,product)) {
			return new ResponseEntity<Boolean>(true, HttpStatus.OK);
		} else {
			return new ResponseEntity<Boolean>(false, HttpStatus.NOT_FOUND);
		}
	}
}
