//package com.cg.capstore.main;
//
//import com.cg.capstore.dao.Dao;
//
//public class Main 
//{	
//	public static void main(String args[])
//	{
//		Dao dao = new Dao();
//		dao.manage();
//
//	}
// }
