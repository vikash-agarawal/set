package com.cg.capstore.dao;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.cg.capstore.bean.Address;
import com.cg.capstore.bean.Product;
@Transactional
public interface ProductDao  extends JpaRepository<Product, Long> {

	@Query("from Product WHERE product_id=:productId")
	public Product getProductfromProductId(int productId);

}
