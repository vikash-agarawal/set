package com.cg.capstore.dao;
import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.capstore.bean.Image;
@Transactional
public interface ImageDao  extends JpaRepository<Image, String> {

}
