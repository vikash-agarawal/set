package com.cg.refundmoney.service;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.refundmoney.bean.Orders;
import com.cg.refundmoney.dao.IReturnDao;



@Service("service")
public class IReturnMoneySerImpl implements IReturnService {


	@Autowired
	public IReturnDao returnDao;

	@Override
	public boolean refundmoney(String orderId) {
		Orders order=returnDao.getOne(orderId);
		if(order.getOrderStatus().equals("Returned"))
		{
			double price=order.getSubTotal();
			System.out.println(order.getPayment_acc_no()+"\n price="+price);
			return true;
		}
		else
		{
			return false;
		}
		
	}
}


	
