package com.cg.refundmoney.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cg.refundmoney.service.IReturnService;


public class ReturnGoodsController
{
	@Autowired
	private IReturnService returnservice;
	
	
	@RequestMapping(value="/refundMoney", method=RequestMethod.GET, consumes=MediaType.APPLICATION_JSON_VALUE)
	public String getrefundMoneyt(String orderId) {
		if(returnservice.refundmoney(orderId))
		{
			
			return "money credeted in  above account number";
		}
		else
			{
			return "not applicable for refund";
		}
	}
}