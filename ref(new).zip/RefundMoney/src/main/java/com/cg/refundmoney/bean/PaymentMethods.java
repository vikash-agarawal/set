package com.cg.refundmoney.bean;

public enum PaymentMethods 
{
	CASH_ON_DELIVERY , NETBANKING , CARD;
}
