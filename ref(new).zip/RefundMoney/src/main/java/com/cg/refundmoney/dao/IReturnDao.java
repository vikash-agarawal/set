package com.cg.refundmoney.dao;


import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;



import com.cg.refundmoney.bean.Orders;


@Transactional
public interface IReturnDao  extends JpaRepository<Orders, String> {
	
}