package com.cg.refundmoney.service;

public interface IReturnService {

	public  boolean refundmoney(String orderId);
		
}
