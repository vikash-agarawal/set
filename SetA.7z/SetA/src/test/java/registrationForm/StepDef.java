package registrationForm;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pagebin.RegistrationFormPageFactory;

public class StepDef {
	
	private WebDriver driver;
	private RegistrationFormPageFactory rfpf;
	
	@Given("^User is on Registration Form page$")
	public void user_is_on_Registration_Form_page() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "driver\\chromedriver.exe");

		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		rfpf=new RegistrationFormPageFactory(driver);
		driver.get("file:///C:/Users/VIKAAGRA/Desktop/SpringFolder/SetA_318/pages/RegistrationForm.html");
	}

	@Then("^check the title of the page$")
	public void check_the_title_of_the_page() throws Throwable {
		String title=driver.getTitle();
		if(title.contentEquals("Welcome to JobsWorld")) System.out.println("****** Title Matched");
		else System.out.println("****** Title NOT Matched");
		driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);
		driver.close();
	}

	@When("^user enters all valid data$")
	public void user_enters_all_valid_data() throws Throwable {
		rfpf.setPfuserID("abcdefgh"); Thread.sleep(1000);
	    rfpf.setPfpwd("123456789"); Thread.sleep(1000);
	    rfpf.setPfusrname("abcd"); Thread.sleep(1000);
	    rfpf.setPfaddr("talwadechowkpune"); Thread.sleep(1000);
	    rfpf.setPfcountry("India"); Thread.sleep(1000);
	    rfpf.setPfzip("123456"); Thread.sleep(1000);
	    rfpf.setPfemail("abs@gmail.com"); Thread.sleep(1000);
	    rfpf.setPfsex("Male"); Thread.sleep(1000);
	    rfpf.setPfen("English"); Thread.sleep(1000);
	    rfpf.setPfdesc("abcdefghihjffk"); Thread.sleep(1000);
	    rfpf.setPfsubmit();
	}

	@Then("^close the driver$")
	public void click_on_submit_button() throws Throwable {
		driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);
		Thread.sleep(1000);
		driver.close();
	}

	@When("^user leaves userid empty$")
	public void user_leaves_userid_empty() throws Throwable {
		rfpf.setPfuserID("");
	}

	@When("^clicks the submit button$")
	public void clicks_the_submit_button() throws Throwable {
		rfpf.setPfsubmit();
	}

	@Then("^display alert msg$")
	public void display_alert_msg() throws Throwable {
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
	    System.out.println("******" + alertMessage);
	    driver.close();
	}

	@When("^user enter wrong length of user id$")
	public void user_enter_wrong_length_of_user_id() throws Throwable {
		rfpf.setPfuserID("ab");
	}

	@When("^user leaves password empty$")
	public void user_leaves_password_empty() throws Throwable {
		rfpf.setPfuserID("abcdefgh"); Thread.sleep(1000);
	    rfpf.setPfpwd(""); Thread.sleep(1000);
	}

	@When("^user enter wrong length of password$")
	public void user_enters_all_data() throws Throwable {
		rfpf.setPfuserID("abcdefgh"); Thread.sleep(1000);
	    rfpf.setPfpwd("123"); Thread.sleep(1000);
	}

	@When("^user leaves Name empty$")
	public void user_leaves_Name_empty() throws Throwable {
		rfpf.setPfuserID("abcdefgh"); Thread.sleep(1000);
	    rfpf.setPfpwd("123456789"); Thread.sleep(1000);
	    rfpf.setPfusrname(""); Thread.sleep(1000);
	}

	@When("^user enter wrong type of name$")
	public void user_enter_wrong_type_of_name() throws Throwable {
		rfpf.setPfuserID("abcdefgh"); Thread.sleep(1000);
	    rfpf.setPfpwd("123456789"); Thread.sleep(1000);
	    rfpf.setPfusrname("1245"); Thread.sleep(1000);
	}

	@When("^user leaves Address empty$")
	public void user_leaves_Address_empty() throws Throwable {
		rfpf.setPfuserID("abcdefgh"); Thread.sleep(1000);
	    rfpf.setPfpwd("123456789"); Thread.sleep(1000);
	    rfpf.setPfusrname("abcd"); Thread.sleep(1000);
	    rfpf.setPfaddr(""); Thread.sleep(1000);
	}

	@When("^user enter wrong type of address$")
	public void user_enter_wrong_type_of_address() throws Throwable {
		rfpf.setPfuserID("abcdefgh"); Thread.sleep(1000);
	    rfpf.setPfpwd("123456789"); Thread.sleep(1000);
	    rfpf.setPfusrname("abcd"); Thread.sleep(1000);
	    rfpf.setPfaddr("a b s"); Thread.sleep(1000);
	}

	@When("^user not select any country$")
	public void user_not_select_any_country() throws Throwable {
		rfpf.setPfuserID("abcdefgh"); Thread.sleep(1000);
	    rfpf.setPfpwd("123456789"); Thread.sleep(1000);
	    rfpf.setPfusrname("abcd"); Thread.sleep(1000);
	    rfpf.setPfaddr("talwadechowkpune"); Thread.sleep(1000);
	    //rfpf.setPfcountry(""); Thread.sleep(1000);
	}

	@When("^user leaves zipcode empty$")
	public void user_leaves_zipcode_empty() throws Throwable {
		rfpf.setPfuserID("abcdefgh"); Thread.sleep(1000);
	    rfpf.setPfpwd("123456789"); Thread.sleep(1000);
	    rfpf.setPfusrname("abcd"); Thread.sleep(1000);
	    rfpf.setPfaddr("talwadechowkpune"); Thread.sleep(1000);
	    rfpf.setPfcountry("India"); Thread.sleep(1000);
	    rfpf.setPfzip(""); Thread.sleep(1000);
	}

	@When("^user enters wrong zipcode$")
	public void user_enters_wrong_zipcode() throws Throwable {
		rfpf.setPfuserID("abcdefgh"); Thread.sleep(1000);
	    rfpf.setPfpwd("123456789"); Thread.sleep(1000);
	    rfpf.setPfusrname("abcd"); Thread.sleep(1000);
	    rfpf.setPfaddr("talwadechowkpune"); Thread.sleep(1000);
	    rfpf.setPfcountry("India"); Thread.sleep(1000);
	    rfpf.setPfzip("abc"); Thread.sleep(1000);
	}

	@When("^user leaves email empty$")
	public void user_leaves_email_empty() throws Throwable {
		rfpf.setPfuserID("abcdefgh"); Thread.sleep(1000);
	    rfpf.setPfpwd("123456789"); Thread.sleep(1000);
	    rfpf.setPfusrname("abcd"); Thread.sleep(1000);
	    rfpf.setPfaddr("talwadechowkpune"); Thread.sleep(1000);
	    rfpf.setPfcountry("India"); Thread.sleep(1000);
	    rfpf.setPfzip("123456"); Thread.sleep(1000);
	    rfpf.setPfemail(""); Thread.sleep(1000);
	}

	@When("^user enters wrong format of email id$")
	public void user_enters_wrong_format_of_email_id() throws Throwable {
		rfpf.setPfuserID("abcdefgh"); Thread.sleep(1000);
	    rfpf.setPfpwd("123456789"); Thread.sleep(1000);
	    rfpf.setPfusrname("abcd"); Thread.sleep(1000);
	    rfpf.setPfaddr("talwadechowkpune"); Thread.sleep(1000);
	    rfpf.setPfcountry("India"); Thread.sleep(1000);
	    rfpf.setPfzip("123456"); Thread.sleep(1000);
	    rfpf.setPfemail("absgsdg"); Thread.sleep(1000);
	}

	@When("^user does not select any gender$")
	public void user_does_not_select_any_gender() throws Throwable {
		rfpf.setPfuserID("abcdefgh"); Thread.sleep(1000);
	    rfpf.setPfpwd("123456789"); Thread.sleep(1000);
	    rfpf.setPfusrname("abcd"); Thread.sleep(1000);
	    rfpf.setPfaddr("talwadechowkpune"); Thread.sleep(1000);
	    rfpf.setPfcountry("India"); Thread.sleep(1000);
	    rfpf.setPfzip("123456"); Thread.sleep(1000);
	    rfpf.setPfemail("abs@gmail.com"); Thread.sleep(1000);
	    rfpf.setPfsex(""); Thread.sleep(1000);
	}

	@When("^select language$")
	public void select_language() throws Throwable {
		rfpf.setPfuserID("abcdefgh"); Thread.sleep(1000);
	    rfpf.setPfpwd("123456789"); Thread.sleep(1000);
	    rfpf.setPfusrname("abcd"); Thread.sleep(1000);
	    rfpf.setPfaddr("talwadechowkpune"); Thread.sleep(1000);
	    rfpf.setPfcountry("India"); Thread.sleep(1000);
	    rfpf.setPfzip("123456"); Thread.sleep(1000);
	    rfpf.setPfemail("abs@gmail.com"); Thread.sleep(1000);
	    rfpf.setPfsex("Male"); Thread.sleep(1000);
	    rfpf.setPfen("English"); Thread.sleep(1000);
	}

	@Then("^clicks the submit buttons$")
	public void clicks_the_submit_buttons() throws Throwable {
	    rfpf.setPfsubmit();
	}
}
