package com.cg.repo;
import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.beans.Response;

@Transactional
public interface ResponseDao  extends JpaRepository<Response, String> {

}
