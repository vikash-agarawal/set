package com.cg.repo;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.beans.Product;




@Transactional
public interface ProductDao  extends JpaRepository<Product, String> {

}
