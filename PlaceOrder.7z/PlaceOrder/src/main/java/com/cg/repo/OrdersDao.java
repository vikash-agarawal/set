package com.cg.repo;


import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;


import com.cg.beans.Orders;


@Transactional
public interface OrdersDao  extends JpaRepository<Orders, String> {
	

}
