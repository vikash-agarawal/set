package com.cg.repo;
import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.beans.Merchant;

@Transactional
public interface MerchantDao  extends JpaRepository<Merchant, String> {

}
