package com.cg.repo;
import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.beans.Address;


@Transactional
public interface AddressDao  extends JpaRepository<Address, String> 
{

}
