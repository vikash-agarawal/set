package com.cg.repo;
import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.beans.Customer;

@Transactional
public interface CustomerDao  extends JpaRepository<Customer, String> {

}
