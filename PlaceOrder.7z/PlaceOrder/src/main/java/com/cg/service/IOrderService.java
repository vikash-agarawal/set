package com.cg.service;

import com.cg.beans.Orders;
import com.cg.beans.Product;

public interface IOrderService {


	public boolean checkAvailabilityInInventory(String productId);
	public Product placeOrder(String productId);
	public boolean deliverOrderAndUpdateInventory(Orders order,Product product);	
	
}