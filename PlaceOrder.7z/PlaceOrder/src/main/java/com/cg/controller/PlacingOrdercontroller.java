package com.cg.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.beans.Orders;
import com.cg.beans.Product;
import com.cg.service.IOrderService;



public class PlacingOrdercontroller {
	
	@Autowired
	private IOrderService OrderService;
	
	@PostMapping("/checkAvailabilityInInventory")//
	public ResponseEntity<Boolean> checkAvailabilityInInventory(@RequestParam ("productId") String productId) {
		if (OrderService.checkAvailabilityInInventory(productId)) {
			return new ResponseEntity<Boolean>(true, HttpStatus.OK);
		} else {
			return new ResponseEntity<Boolean>(false, HttpStatus.NOT_FOUND);
		}
	}
	

	@PostMapping("/placeOrder")
	public ResponseEntity<Product> placeOrder(@RequestParam ("productId") String productId) {
		Product nullproduct = null;
		if (!OrderService.checkAvailabilityInInventory(productId)) {
			return new ResponseEntity<Product>(nullproduct, HttpStatus.OK);
		}
		
		Product newproduct = OrderService.placeOrder(productId);
		if (newproduct!=null) {
			return new ResponseEntity<Product>(newproduct, HttpStatus.OK);
		} else {
			return new ResponseEntity<Product>(nullproduct, HttpStatus.NOT_FOUND);
		}
	}

	@PostMapping("/deliverOrderAndUpdateInventory")//
	public ResponseEntity<Boolean> deliverOrderAndUpdateInventory(@RequestBody Orders order,@RequestBody Product product) {
		if (OrderService.deliverOrderAndUpdateInventory(order,product)) {
			return new ResponseEntity<Boolean>(true, HttpStatus.OK);
		} else {
			return new ResponseEntity<Boolean>(false, HttpStatus.NOT_FOUND);
		}
	}
	

}
