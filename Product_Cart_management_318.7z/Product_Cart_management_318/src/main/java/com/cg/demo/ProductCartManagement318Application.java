package com.cg.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan("com.cg")
@EntityScan("com.cg.demo.bean")
public class ProductCartManagement318Application {

	public static void main(String[] args) {
		SpringApplication.run(ProductCartManagement318Application.class, args);
	}

}
