package com.cg.demo.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.demo.bean.Product;
import com.cg.demo.repo.IProductRepo;


@Transactional
@Service("service")
public class ProductServiceImpl implements IProductService {
	
	@Autowired
	IProductRepo repo;
	
	

	public IProductRepo getRepo() {
		return repo;
	}

	public void setRepo(IProductRepo repo) {
		this.repo = repo;
	}

	@Override
	public Product createProduct(Product product) {
	
		return repo.createProduct(product);
	}

	@Override
	public ArrayList<Product> viewAllProduct() {
		
		return repo.viewAllProduct();
	}

	@Override
	public Product getById(String id) {
		
		return repo.getById(id);
	}

	@Override
	public Product updateProduct(Product product) {
		
		return repo.updateProduct(product);
	}

	@Override
	public Product removeProduct(String customerId) {
		
		return repo.removeProduct(customerId);
	}

}
