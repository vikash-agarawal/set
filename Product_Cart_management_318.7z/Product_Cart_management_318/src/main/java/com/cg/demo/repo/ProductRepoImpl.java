package com.cg.demo.repo;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.demo.bean.Product;





@Repository
public class ProductRepoImpl implements IProductRepo {
	
	@PersistenceContext
	EntityManager entitymanager;
	
	public EntityManager getEntitymanager() {
		return entitymanager;
	}



	public void setEntitymanager(EntityManager entitymanager) {
		this.entitymanager = entitymanager;
	}

	@Override
	public Product createProduct(Product product) {
		entitymanager.persist(product);
		entitymanager.flush();
		return product;
	}

	@Override
	public ArrayList<Product> viewAllProduct() {
		String selALLQry= " SELECT pro FROM Product pro";
		TypedQuery<Product> tq = entitymanager.createQuery(selALLQry,Product.class);
		ArrayList<Product> proList = (ArrayList<Product>) tq.getResultList();
		return proList ;
	}

	@Override
	public Product getById(String id) {
		Product product=entitymanager.find(Product.class, id);
		
		return product;
	}

	@Override
	public Product updateProduct(Product product) {
		entitymanager.merge(product);
		entitymanager.flush();
		return product;
	}

	@Override
	public Product removeProduct(String id) {
		Product product= entitymanager.find(Product.class, id);
		entitymanager.remove(product);
		entitymanager.flush();
		return product;
	}

}
