/**
 * 
 */
package com.cg.demo.service;

import java.util.ArrayList;

import com.cg.demo.bean.Product;

public interface IProductService {
	public Product createProduct(Product product);
	public ArrayList<Product> viewAllProduct();
	public Product getById(String id);
	public Product updateProduct(Product product);
	public Product removeProduct(String customerId);

}
