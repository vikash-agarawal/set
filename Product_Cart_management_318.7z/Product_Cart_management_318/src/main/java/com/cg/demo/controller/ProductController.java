package com.cg.demo.controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.demo.bean.Product;
import com.cg.demo.service.IProductService;


@RestController
public class ProductController {
	@Autowired
	IProductService service;
	@RequestMapping(value="/welcome",method=RequestMethod.GET)
	public String printHello()
	{
		return "Hello";
	}
	
	@RequestMapping(value="/createProduct",method=RequestMethod.POST,produces="application/json")
	public Product createProduct(@RequestBody Product product)
	{
	
		product = service.createProduct(product);
		return product;
		
	}
	@RequestMapping(value="/viewAllProduct",method=RequestMethod.GET,produces="application/json",consumes="application/json")
	public ArrayList<Product> viewAllProduct()
	{
		ArrayList<Product> prolist=service.viewAllProduct();
		return prolist;
	}
	@RequestMapping(value="/getById/{id}",method=RequestMethod.GET,produces="application/json")
	public Product getByID(@PathVariable String id )
	{
		Product product=service.getById(id);
		return product;
	}
	@RequestMapping(value="/delete/{id}",method=RequestMethod.GET,produces="application/json")
	public Product delete(@PathVariable String id )
	{
		Product product=service.removeProduct(id);
		return product;
	}
	@RequestMapping(value="/update",method=RequestMethod.POST,produces="application/json",consumes="application/json")
	public Product update(@RequestBody Product product)
	{
	
		product = service.updateProduct(product);
		return product;
		
	}
	
}

