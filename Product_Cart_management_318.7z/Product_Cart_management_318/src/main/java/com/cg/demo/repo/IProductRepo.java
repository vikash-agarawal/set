package com.cg.demo.repo;

import java.util.ArrayList;

import com.cg.demo.bean.Product;

public interface IProductRepo {
	public Product createProduct(Product product);
	public ArrayList<Product> viewAllProduct();
	public Product getById(String id);
	public Product updateProduct(Product product);
	public Product removeProduct(String customerId);
}
